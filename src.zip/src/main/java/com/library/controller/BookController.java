package com.library.controller;

import com.github.pagehelper.PageInfo;
import com.library.po.BookInfo;
import com.library.service.BookInfoService;
import com.library.util.R;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class BookController {
    @Autowired
    private BookInfoService bookInfoService;
    /**
     * 图书首页
     */
    @GetMapping("/bookIndex")
    public String bookIndex(){
        return "/book/bookIndex";
    }

    /**
     * 获取图书信息
     * @return
     */
    @ResponseBody
    @RequestMapping("/bookAll")
    public R bookAll(BookInfo info, @RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "15") int limit ){
        PageInfo<BookInfo> pageInfo = bookInfoService.queryBookInfoAll(info, page, limit);

        return R.ok("successful", pageInfo.getTotal(), pageInfo.getList());
    }


}
